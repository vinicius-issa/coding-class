function souEu(nome){
  if (nome === 'vinicius')
    return true
  else
    return false
}

function chamada(numero){
  if (numero === 1){
    return ('João')
  }
  else if (numero === 2){
    return ('Maria')
  }
  else if (numero === 3){
    return ('joana')
  }
  else if (numero === 4){
    return ('Carlos')
  }
  else{
    return ('nao encontrado')
  }
}

function podeEntrar(idade, acompanhado){
  if (idade >= 18){
    return 'pode entrar'
  }
  else if( acompanhado ){
    return 'pode entrar'
  }
  else{
    return 'nao pode entrar'
  }
}

function passouDeAno(nota){
  if (nota < 4){
    return 'reprovado'
  }
  else if (nota>=4 && nota < 7){
    return 'recuperaçao'
  }
  else{
    return 'aprovado'
  }
}